Daniel Gebara, 300401006
Jad Mroueh, 300425804
Hussain Ghadbawi, 300401252