package SEGq2;

import java.time.LocalDate;

public class Minor extends Client {
    public Minor(String clientId, String name, String email, LocalDate birthDate) {
        super(clientId, name, email, birthDate);
    }
}

