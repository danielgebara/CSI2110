Members:
Jad Mroueh, jmrou009@uottawa.ca, 300425804
Daniel Gebara, dgeba011@uottawa.ca, 300401006